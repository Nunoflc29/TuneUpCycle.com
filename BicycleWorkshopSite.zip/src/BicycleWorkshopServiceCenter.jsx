import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useState } from "react";

const services = [
  { name: "Bronze Service", price: 45, description: "Basic safety check and adjustments." },
  { name: "Silver Service", price: 75, description: "Full check and tune-up, including brakes and gears." },
  { name: "Gold Service", price: 120, description: "Comprehensive service including full strip down and rebuild." },
];

export default function BicycleWorkshopServiceCenter() {
  const [formData, setFormData] = useState({ name: "", email: "", message: "" });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    alert("Form submitted! We'll get back to you soon.");
    // Optionally integrate with a service like Formspree or EmailJS
  };

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-12">
      <div className="space-y-4">
        <h1 className="text-4xl font-bold text-center">The Bicycle Workshop Service Center</h1>
        <p className="text-center text-lg text-gray-600">Professional bike servicing and repairs</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {services.map((service) => (
          <Card key={service.name} className="rounded-2xl shadow-md">
            <CardContent className="p-6 space-y-4">
              <h2 className="text-2xl font-semibold">{service.name}</h2>
              <p className="text-gray-500">{service.description}</p>
              <p className="text-xl font-bold">£{service.price}</p>
              <form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_blank">
                <input type="hidden" name="cmd" value="_xclick" />
                <input type="hidden" name="business" value="nunoflc@hotmail.co.uk" />
                <input type="hidden" name="item_name" value={service.name} />
                <input type="hidden" name="amount" value={service.price} />
                <input type="hidden" name="currency_code" value="GBP" />
                <Button type="submit" className="w-full">Pay with PayPal</Button>
              </form>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="bg-gray-100 p-6 rounded-2xl shadow-md">
        <h2 className="text-3xl font-bold mb-4">Contact / Booking Form</h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="name">Name</Label>
            <Input type="text" id="name" name="name" value={formData.name} onChange={handleChange} required />
          </div>
          <div>
            <Label htmlFor="email">Email</Label>
            <Input type="email" id="email" name="email" value={formData.email} onChange={handleChange} required />
          </div>
          <div>
            <Label htmlFor="message">Message / Preferred Booking Time</Label>
            <Textarea id="message" name="message" value={formData.message} onChange={handleChange} required />
          </div>
          <Button type="submit">Submit</Button>
        </form>
      </div>
    </div>
  );
}
